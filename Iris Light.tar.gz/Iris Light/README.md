=======
iris-light
==========

A light, clean, flat and bold Gtk theme.
The window decoration themes do not currently work, with the exception of the Metacity theme.

Also see Iris Dark at github.com/xyl0n/iris
